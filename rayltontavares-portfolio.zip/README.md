
# Portfólio de Raylton Tavares

Este é o site pessoal de Raylton Tavares, contendo currículo interativo, informações sobre experiência, projetos e formas de contato.

## 🚀 Como publicar no Netlify

1. Acesse [https://app.netlify.com/drop](https://app.netlify.com/drop)
2. Arraste todos os arquivos da pasta deste projeto
3. Netlify gerará uma URL temporária
4. Em Settings > Domain Management, conecte o domínio `rayltontavares.dev`

## 🌐 Como publicar no GitHub Pages

1. Faça push dos arquivos para um repositório público
2. Vá em Settings > Pages
3. Escolha a branch `main` e root como `/`
